﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApiPonto.Repositories
{
    public class Contexto
    {
        internal readonly MySqlConnection _connection;

        public Contexto()
        {
            _connection = new MySqlConnection("Server=sql10.freemysqlhosting.net;Database=sql10594288;Uid=sql10594288;Pwd=ImBwvHU5vg;");
        }
        public void AbrirConexao()
        {
            _connection.Open();
        }
        public void FecharConexao()
        {
            _connection.Close();
        }
    }
}
