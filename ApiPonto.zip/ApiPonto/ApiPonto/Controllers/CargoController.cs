﻿using ApiPonto.Domain.Exceptions;
using ApiPonto.Domain.Models;
using ApiPonto.Services.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Data;


namespace ApiPonto.Controllers
{
    public class CargoController : ControllerBase
    {
        private readonly CargoServices _cargoServices;
        public CargoController()
        {
            _cargoServices = new CargoServices();
        }

        [Authorize(Roles = "1,2,3")]
        [HttpGet("cargo")]
        public IActionResult Listar([FromQuery] string? nome)
        {
            return StatusCode(200, _cargoServices.Listar(nome));
        }

        [Authorize(Roles = "2")]
        [HttpPost("cargo")]
        public IActionResult Inserir([FromQuery] Cargo model)
        {
            try
            {
                _cargoServices.Inserir(model);
                return StatusCode(201);
            }
            catch (ValidacaoException ex)
            {
                return StatusCode(400, ex.Message);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.ToString());
            }
        }

        [Authorize(Roles = "2")]
        [HttpDelete("cargo")]
        public IActionResult Deletar([FromQuery] int id)
        {
            try
            {
                _cargoServices.Deletar(id);
                return StatusCode(200, "cargo apagado com sucesso");
            }
            catch (ValidacaoException ex)
            {
                return StatusCode(400, ex.Message);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.ToString());
            }
        }

        [Authorize(Roles = "2")]
        [HttpPut("cargo")]
        public IActionResult Atualizar([FromQuery] Cargo model)
        {
            try
            {
                _cargoServices.Atualizar(model);
                return StatusCode(201, "Atualizado com sucesso");
            }
            catch (ValidacaoException ex)
            {
                return StatusCode(400, ex.Message);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.ToString());
            }
        }
    }

}
