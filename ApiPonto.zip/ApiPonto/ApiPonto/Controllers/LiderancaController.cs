﻿using ApiPonto.Domain.Models;
using ApiPonto.Services.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Data;
using ApiPonto.Domain.Exceptions;

namespace ApiPonto.Controllers
{
    public class LiderancaController : ControllerBase
    {

        private readonly LiderancaService _liderancasService;

        public LiderancaController()
        {

            _liderancasService = new LiderancaService();
        }

        [Authorize(Roles = "1,2,3")]
        [HttpGet("lideranca")]
        public IActionResult Listar([FromQuery] string? descricao)
        {
            return StatusCode(200, _liderancasService.Listar(descricao));
        }

        [Authorize(Roles = "2")]
        [HttpPost("lideranca")]
        public IActionResult Inserir([FromQuery] Lideranca lideranca)
        {
            try
            {
                _liderancasService.Inserir(lideranca);
                return StatusCode(201);
            }
            catch (ValidacaoException ex)
            {
                return StatusCode(400, ex.Message);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.ToString());
            }
        }

        [Authorize(Roles = "2")]
        [HttpDelete("lideranca")]

        public IActionResult Apagar([FromQuery] int liderancaId)
        {
            try
            {
                _liderancasService.Apagar(liderancaId);
                return StatusCode(200, "Liderança apagado do banco de dados");
            }
            catch (ValidacaoException ex)
            {
                return StatusCode(400, ex.Message);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.ToString());
            }

        }

        [Authorize(Roles = "2")]
        [HttpPut("lideranca")]
        public IActionResult Atualizar([FromQuery] Lideranca lideranca
            )
        {
            try
            {
                _liderancasService.Atualizar(lideranca);
                return StatusCode(201);
            }
            catch (ValidacaoException ex)
            {
                return StatusCode(400, ex.Message);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.ToString());
            }
        }
    }
}
