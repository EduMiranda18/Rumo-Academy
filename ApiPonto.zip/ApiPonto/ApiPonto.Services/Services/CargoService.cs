﻿using ApiPonto.Domain.Models;
using ApiPonto.Repositories.Repositorio;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ApiPonto.Domain.Exceptions;

namespace ApiPonto.Services.Services
{
    public class CargoServices
    {
       
        private readonly CargoRepositorio _cargoRepositorio;
        public CargoServices()
        {
            _cargoRepositorio = new CargoRepositorio();
        }
        public List<Cargo> Listar(string? descricao)
        {
            try
            {
                _cargoRepositorio.AbrirConexao();
                return _cargoRepositorio.ListarCargos(descricao);
            }
            finally
            {
                _cargoRepositorio.FecharConexao();
            }
        }
        
        public void Inserir(Cargo model)
        {
            try
            {
                ValidarModelCargo(model);
                _cargoRepositorio.AbrirConexao();
                _cargoRepositorio.Inserir(model);
            }
            finally
            {
                _cargoRepositorio.FecharConexao();
            }
        }

        public void Deletar(int id)
        {
            try
            {
                _cargoRepositorio.AbrirConexao();

                if (!_cargoRepositorio.SeExiste(id))
                    throw new ValidacaoException($"Nenhum registro afetado para o identificaro de número {id}");

                _cargoRepositorio.Deletar(id);
            }
            finally
            {
                _cargoRepositorio.FecharConexao();
            }
        }

        public void Atualizar(Cargo model)
        {
            try
            {

                ValidarModelCargo(model);
                _cargoRepositorio.AbrirConexao();
                if (!_cargoRepositorio.SeExisteAtualizar(model))
                    throw new ValidacaoException($"Nenhum registro afetado para o identificaro de número {model.CargoId}");
                _cargoRepositorio.Atualizar(model);
            }
            finally
            {
                _cargoRepositorio.FecharConexao();
            }
        }

        private static void ValidarModelCargo(Cargo model)
        {
            if (string.IsNullOrWhiteSpace(model.Descricao))
                throw new ValidacaoException("A descrição do cargo é obrigatório.");

            if (model.Descricao.Trim().Length < 2 || model.Descricao.Trim().Length > 255)
                throw new ValidacaoException("O nome precisa ter entre 2 a 255 caracteres.");

            model.Descricao = model.Descricao.Trim();
        }

    }
}