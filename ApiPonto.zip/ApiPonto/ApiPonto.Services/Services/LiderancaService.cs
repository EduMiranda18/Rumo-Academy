﻿using ApiPonto.Domain.Models;
using ApiPonto.Repositories.Repositorio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ApiPonto.Domain.Exceptions;

namespace ApiPonto.Services.Services
{
    public class LiderancaService
    {

        private readonly LiderancaRepositorio _liderancasRepositorio;

        public LiderancaService()
        {
            _liderancasRepositorio = new LiderancaRepositorio();
        }
        public List<Lideranca> Listar(string? nome)
        {
            try
            {
                _liderancasRepositorio.AbrirConexao();
                return _liderancasRepositorio.ListarLideres(nome);
            }
            finally
            {
                _liderancasRepositorio.FecharConexao();
            }
        }

        public void Inserir(Lideranca lideranca)
        {
            try
            {
                ValidarDescricao(lideranca);
                _liderancasRepositorio.AbrirConexao();
                _liderancasRepositorio.Inserir(lideranca);
            }
            finally
            {
                _liderancasRepositorio.FecharConexao();
            }
        }

        public void Apagar(int id)
        {
            try
            {
                _liderancasRepositorio.AbrirConexao();
                if (!_liderancasRepositorio.SeExiste((id)))
                    throw new ValidacaoException($"Nenhum registro encontrado para o Cpf {id}");
                _liderancasRepositorio.Apagar(id);
            }
            finally
            {

                _liderancasRepositorio.FecharConexao();

            }
        }

        public void Atualizar(Lideranca lideranca)
        {
            try
            {
                ValidarDescricao(lideranca);
                _liderancasRepositorio.AbrirConexao();
                if (!_liderancasRepositorio.SeExiste(lideranca.LiderancaId))
                    throw new ValidacaoException($"Nenhum registro encontrado para o identificador de liderança {lideranca.LiderancaId}");
                _liderancasRepositorio.Atualizar(lideranca);
            }
            finally
            {
                _liderancasRepositorio.FecharConexao();
            }
        }

        private static void ValidarDescricao(Lideranca lideranca)
        {
            if (string.IsNullOrWhiteSpace(lideranca.FuncionarioId.ToString()))
                throw new ValidacaoException("O identificador do usuario é obrigatorio.");

            if (string.IsNullOrWhiteSpace(lideranca.DescricaoEquipe))
                throw new ValidacaoException("A descriçaõ da equipe é obrigatoria.");
            if (lideranca.DescricaoEquipe.Trim().Length < 2
                || lideranca.DescricaoEquipe.Trim().Length > 155)
                throw new ValidacaoException("A descrição do cargo precisa ter entre 2 e 155 caracteres");
        }
    }
}
